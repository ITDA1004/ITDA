package com.example.it_da;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Vibrator;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

import static com.example.it_da.Constants.REQUEST_ENABLE_BT;

public class MainActivity extends AppCompatActivity {

    private final String TAG = MainActivity.class.getSimpleName();

    private TextView tvStatus;
    private Button btnStop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = new Intent(MainActivity.this, ScreenService.class);
        startService(intent);

        initView();
        initServer();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_ENABLE_BT)
            initServer();
    }

    /*@Override
    public void onBackPressed() {
        showStatusMsg("Close Server");
        *//**
         * 액티비티가 종료될때 서버를 종료시켜주기 위한 처리.
         *//*
        PeripheralManager.getInstance(MainActivity.this).close();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                finish();
            }
        }, 500);
    }*/

    /**
     * 텍스트뷰와 버튼 바인딩.
     * 버튼 이벤트 셋팅.
     */
    private void initView() {
        tvStatus = (TextView) findViewById(R.id.tv_status);
        btnStop = (Button) findViewById(R.id.btnStop);

        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PeripheralManager.getInstance(MainActivity.this).close();
                Intent intent = new Intent(MainActivity.this, ScreenService.class);
                stopService(intent);
                finish();
            }
        });
    }

    /**
     * Gatt Server 시작.
     * Peripheral Callback 을 셋팅해준다.
     */
    private void initServer() {
        PeripheralManager.getInstance(MainActivity.this).setCallBack(peripheralCallback);
        PeripheralManager.getInstance(MainActivity.this).initServer();
    }

    /**
     * 불루투스 기능을 켠다.
     */
    private void requestEnableBLE() {
        Intent ble_enable_intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        startActivityForResult(ble_enable_intent, REQUEST_ENABLE_BT);
    }

    /**
     * 텍스트뷰에 메세지를 표시한다.
     * @param message
     */
    private void showStatusMsg(final String message) {
        Handler handler = new Handler(Looper.getMainLooper()) {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);

                String oldMsg = tvStatus.getText().toString();
                tvStatus.setText(oldMsg + "\n" + message);

                scrollToBottom();
            }
        };
        handler.sendEmptyMessage(1);
    }

    /**
     * 토스트를 표시한다.
     * @param message
     */
    private void checkViberate(final String message) {
        Handler handler = new Handler(Looper.getMainLooper()) {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                if(message.equals("1")){
                    final Vibrator vibrator = (Vibrator)getSystemService(MainActivity.this.VIBRATOR_SERVICE);
                    vibrator.vibrate(500);
                }
                //Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        };
        handler.sendEmptyMessage(1);
    }

    /**
     * 텍스트뷰에 메세지를 표시하면 스크롤을 아래로 이동시킨다.
     */
    private void scrollToBottom() {
        final ScrollView scrollview = ((ScrollView) findViewById(R.id.scrollview));
        scrollview.post(new Runnable() {
            @Override public void run() {
                scrollview.fullScroll(ScrollView.FOCUS_DOWN);
            }
        });
    }

    /**
     * Peripheral Callback
     */
    PeripheralCallback peripheralCallback = new PeripheralCallback() {
        @Override
        public void requestEnableBLE() {
            MainActivity.this.requestEnableBLE();
        }

        @Override
        public void onStatusMsg(String message) {
            showStatusMsg(message);
        }

        @Override
        public void onToast(String message) {
            checkViberate(message);
        }
    };
}